import os
import base64
import io
import requests
from PIL import Image

SYSTEM_PROMPT = (
    "You are NutriAI, a friendly expert AI assistant specializing in nutrition, food science, "
    "health, and diet. Answer questions about calories, nutrients, meal plans, healthy eating, "
    "fitness, supplements, and general health. When given an image, identify food and provide "
    "nutritional info. Use markdown formatting (bold, bullets, headers) for clear responses. "
    "Be warm, accurate, and concise."
)


def ask_ai(message, image_data=None, history=None):
    """
    Ask AI. Priority:
      1. Google Gemini (if GEMINI_API_KEY is set and valid)
      2. Pollinations.ai (free, no key needed — always works)
    """
    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
    if gemini_key and gemini_key not in ("your_gemini_api_key_here", ""):
        try:
            return _ask_gemini(message, image_data, gemini_key, history)
        except Exception as e:
            print(f"[Gemini error, falling back to Pollinations]: {e}")

    # Free fallback — always works, no key
    return _ask_pollinations(message, image_data, history)


# ── Gemini ────────────────────────────────────────────────────────────────────
def _ask_gemini(message, image_data, api_key, history=None):
    import google.generativeai as genai
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(
        model_name="gemini-flash-latest",
        system_instruction=SYSTEM_PROMPT
    )
    
    # Format history for Gemini chat if present
    gemini_history = []
    if history:
        for msg in history:
            role = "user" if msg["role"] == "user" else "model"
            gemini_history.append({"role": role, "parts": [msg["content"]]})
            
    # We can either use model.start_chat(history=gemini_history) or just append text.
    # Since we might have an image in THIS prompt, we can use start_chat.
    chat = model.start_chat(history=gemini_history)
    
    content = []
    if image_data:
        if "," in image_data:
            image_data = image_data.split(",")[1]
        raw = base64.b64decode(image_data)
        img = Image.open(io.BytesIO(raw))
        if img.mode not in ("RGB", "RGBA"):
            img = img.convert("RGB")
        content.append(img)
    content.append(message)
    response = chat.send_message(content)
    return response.text


# ── Pollinations.ai (free, no auth) ──────────────────────────────────────────
def _ask_pollinations(message, image_data=None, history=None):
    try:
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        if history:
            messages.extend(history)
            
        messages.append({"role": "user", "content": message})
        
        resp = requests.post(
            "https://text.pollinations.ai/",
            json={"messages": messages, "model": "openai", "private": True},
            timeout=30
        )
        if resp.status_code == 200:
            text = resp.text
            # Clean up any non-printable chars for safe display
            return text.encode("utf-8", errors="replace").decode("utf-8")
        return f"⚠️ AI service returned status {resp.status_code}. Please add your Gemini API key to `.env`."
    except requests.Timeout:
        return "⚠️ AI response timed out. Try again, or add your Gemini API key to `.env` for faster results."
    except Exception as e:
        return f"⚠️ AI Error: {str(e)}"