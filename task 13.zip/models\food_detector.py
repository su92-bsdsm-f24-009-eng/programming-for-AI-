import os
import base64
import io
from PIL import Image


# Fallback: Try Clarifai, else use Gemini vision for food detection
def detect_food(image_path=None, image_bytes=None):
    """Detect food items in an image using Clarifai, with Gemini fallback."""

    # Try Clarifai first
    result = _detect_with_clarifai(image_path, image_bytes)
    if result:
        return result

    # Fallback: use Gemini vision
    return _detect_with_gemini(image_path, image_bytes)


def _detect_with_clarifai(image_path=None, image_bytes=None):
    pat = os.getenv("CLARIFAI_PAT", "")
    if not pat:
        return []
    try:
        from clarifai.client.model import Model
        model = Model(
            url="https://clarifai.com/clarifai/main/models/food-item-recognition",
            pat=pat
        )
        if image_path:
            response = model.predict_by_filename(image_path)
        elif image_bytes:
            response = model.predict_by_bytes(image_bytes, input_type="image")
        else:
            return []

        foods = []
        for concept in response.outputs[0].data.concepts[:6]:
            if concept.value > 0.5:  # Only confident predictions
                foods.append(concept.name)
        return foods
    except Exception as e:
        print(f"Clarifai error: {e}")
        return []


def _detect_with_gemini(image_path=None, image_bytes=None):
    """Use Gemini Vision as fallback for food detection."""
    api_key = os.getenv("GEMINI_API_KEY", "")
    if not api_key or api_key == "your_gemini_api_key_here":
        return ["unknown food"]

    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-flash-latest")

        if image_path:
            with open(image_path, "rb") as f:
                img_bytes = f.read()
        elif image_bytes:
            img_bytes = image_bytes
        else:
            return ["unknown food"]

        image = Image.open(io.BytesIO(img_bytes))
        prompt = (
            "Look at this image and identify all food items you can see. "
            "Return ONLY a comma-separated list of food names, nothing else. "
            "Example: apple, rice, chicken breast, broccoli"
        )
        response = model.generate_content([image, prompt])
        foods = [f.strip() for f in response.text.split(",") if f.strip()]
        return foods[:6]
    except Exception as e:
        print(f"Gemini food detection error: {e}")
        return ["food item"]