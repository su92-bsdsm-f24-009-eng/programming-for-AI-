// ── State ──
let pendingImage = null; // { dataUrl, file }
let isThinking = false;
let cameraStream = null;
let scanContext = 'chat'; // 'chat' or 'scanner'
let chatHistory = []; // Tracks chat context for AI memory

// ── Marked.js renderer ──
function renderMarkdown(text) {
  if (typeof marked !== 'undefined') {
    return marked.parse(text || '');
  }
  return text
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/`(.+?)`/g, '<code>$1</code>')
    .replace(/\n/g, '<br>');
}

// ── Tab switching ──
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.add('active');
  });
});

// ── Chat ──
const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');
const previewBar = document.getElementById('imagePreviewBar');
const previewThumb = document.getElementById('previewThumb');

function appendMessage(role, content, imgSrc) {
  const welcome = document.getElementById('welcomeMsg');
  if (welcome) welcome.remove();

  const div = document.createElement('div');
  div.className = `msg ${role}`;

  const avatar = document.createElement('div');
  avatar.className = 'msg-avatar';
  avatar.textContent = role === 'user' ? '👤' : '🌿';

  const bubble = document.createElement('div');
  bubble.className = 'msg-bubble';

  if (imgSrc) {
    const img = document.createElement('img');
    img.src = imgSrc;
    img.className = 'msg-image';
    bubble.appendChild(img);
  }

  const textDiv = document.createElement('div');
  if (role === 'bot') {
    textDiv.innerHTML = renderMarkdown(content);
  } else {
    textDiv.textContent = content;
  }
  bubble.appendChild(textDiv);

  div.appendChild(avatar);
  div.appendChild(bubble);
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return bubble;
}

function showTyping() {
  const div = document.createElement('div');
  div.className = 'msg bot';
  div.id = 'typingIndicator';
  div.innerHTML = `<div class="msg-avatar">🌿</div>
    <div class="msg-bubble"><div class="typing-dots"><span></span><span></span><span></span></div></div>`;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function removeTyping() {
  const t = document.getElementById('typingIndicator');
  if (t) t.remove();
}

async function sendMessage() {
  if (isThinking) return;
  const text = chatInput.value.trim();
  const img = pendingImage;

  if (!text && !img) return;

  chatInput.value = '';
  chatInput.style.height = 'auto';
  clearPendingImage();
  sendBtn.disabled = true;
  isThinking = true;

  appendMessage('user', text || '(image)', img ? img.dataUrl : null);
  showTyping();
  
  if (text) {
    chatHistory.push({ role: "user", content: text });
  }

  try {
    const body = { 
      message: text || 'Analyze this image and describe what food you see with nutritional info.',
      history: chatHistory
    };
    if (img) body.image = img.dataUrl;

    const res = await fetch('/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    removeTyping();
    const reply = data.reply || data.error || 'No response.';
    appendMessage('bot', reply);
    chatHistory.push({ role: "assistant", content: reply });
  } catch (e) {
    removeTyping();
    appendMessage('bot', '⚠️ Network error. Make sure the Flask server is running.');
  } finally {
    sendBtn.disabled = false;
    isThinking = false;
  }
}

sendBtn.addEventListener('click', sendMessage);
chatInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});
chatInput.addEventListener('input', () => {
  chatInput.style.height = 'auto';
  chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
});

// Quick chips
document.querySelectorAll('.chip').forEach(chip => {
  chip.addEventListener('click', () => {
    chatInput.value = chip.dataset.msg;
    chatInput.dispatchEvent(new Event('input'));
    chatInput.focus();
  });
});

// ── Image attach (chat) ──
const fileInput = document.getElementById('fileInput');
document.getElementById('attachBtn').addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', e => {
  const file = e.target.files[0];
  if (file) loadImageFile(file, 'chat');
  fileInput.value = '';
});

function loadImageFile(file, ctx) {
  const reader = new FileReader();
  reader.onload = ev => {
    if (ctx === 'chat') {
      pendingImage = { dataUrl: ev.target.result, file };
      previewThumb.src = ev.target.result;
      previewBar.classList.add('show');
    } else {
      showScanPreview(ev.target.result);
    }
  };
  reader.readAsDataURL(file);
}

function clearPendingImage() {
  pendingImage = null;
  previewBar.classList.remove('show');
  previewThumb.src = '';
}
document.getElementById('previewRemove').addEventListener('click', clearPendingImage);

// ── Camera modal ──
const cameraModal = document.getElementById('cameraModal');
const cameraVideo = document.getElementById('cameraVideo');

async function openCamera(ctx) {
  scanContext = ctx;
  cameraModal.classList.add('show');
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: ctx === 'scanner' ? 'environment' : 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false
    });
    cameraVideo.srcObject = cameraStream;
  } catch (e) {
    closeCamera();
    showToast('📷 Camera access denied. Please allow camera permissions.');
  }
}

function closeCamera() {
  cameraModal.classList.remove('show');
  if (cameraStream) { cameraStream.getTracks().forEach(t => t.stop()); cameraStream = null; }
  cameraVideo.srcObject = null;
}

function capturePhoto() {
  const canvas = document.createElement('canvas');
  canvas.width = cameraVideo.videoWidth;
  canvas.height = cameraVideo.videoHeight;
  canvas.getContext('2d').drawImage(cameraVideo, 0, 0);
  const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
  closeCamera();

  if (scanContext === 'chat') {
    pendingImage = { dataUrl, file: null };
    previewThumb.src = dataUrl;
    previewBar.classList.add('show');
  } else {
    showScanPreview(dataUrl);
  }
}

document.getElementById('cameraBtnChat').addEventListener('click', () => openCamera('chat'));
document.getElementById('captureBtn').addEventListener('click', capturePhoto);
document.getElementById('closeCameraBtn').addEventListener('click', closeCamera);
document.getElementById('modalOverlay').addEventListener('click', e => {
  if (e.target === document.getElementById('modalOverlay')) closeCamera();
});

// ── Scanner Panel ──
const scanFileInput = document.getElementById('scanFileInput');
const scanPreviewImg = document.getElementById('scanPreviewImg');
const foodResults = document.getElementById('foodResults');
const scanLoader = document.getElementById('scanLoader');
let pendingScanImage = null;

document.getElementById('scanUploadBtn').addEventListener('click', () => scanFileInput.click());
document.getElementById('scanCameraBtn').addEventListener('click', () => openCamera('scanner'));
scanFileInput.addEventListener('change', e => {
  const file = e.target.files[0];
  if (file) loadImageFile(file, 'scanner');
  scanFileInput.value = '';
});

// Drag & drop on upload zone
const uploadZone = document.getElementById('uploadZone');
uploadZone.addEventListener('click', () => scanFileInput.click());
uploadZone.addEventListener('dragover', e => { e.preventDefault(); uploadZone.classList.add('drag-over'); });
uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('drag-over'));
uploadZone.addEventListener('drop', e => {
  e.preventDefault();
  uploadZone.classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) loadImageFile(file, 'scanner');
});

function showScanPreview(dataUrl) {
  pendingScanImage = dataUrl;
  scanPreviewImg.src = dataUrl;
  scanPreviewImg.classList.add('show');
  uploadZone.style.display = 'none';
  foodResults.innerHTML = '';
  document.getElementById('scanFoodBtn').style.display = 'flex';
}

document.getElementById('scanResetBtn').addEventListener('click', () => {
  pendingScanImage = null;
  scanPreviewImg.classList.remove('show');
  uploadZone.style.display = '';
  foodResults.innerHTML = '';
  document.getElementById('scanFoodBtn').style.display = 'none';
  document.getElementById('scanResetBtn').style.display = 'none';
  scanLoader.classList.remove('show');
});

document.getElementById('scanFoodBtn').addEventListener('click', async () => {
  if (!pendingScanImage) return;
  scanLoader.classList.add('show');
  foodResults.innerHTML = '';
  document.getElementById('scanFoodBtn').style.display = 'none';
  document.getElementById('scanResetBtn').style.display = 'flex';

  try {
    const res = await fetch('/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ image: pendingScanImage, history: chatHistory })
    });
    const data = await res.json();
    scanLoader.classList.remove('show');
    renderFoodCards(data.results || [], data.evaluation);
  } catch (e) {
    scanLoader.classList.remove('show');
    foodResults.innerHTML = '<p style="color:var(--coral);text-align:center">⚠️ Error scanning image. Try again.</p>';
  }
});

function renderFoodCards(results, evaluation) {
  if (!results.length) {
    foodResults.innerHTML = '<p style="color:var(--text-secondary);text-align:center">No food detected. Try a clearer image.</p>';
    return;
  }
  let totalCal = 0;
  results.forEach(item => {
    const cal = item.calories;
    if (typeof cal === 'number') totalCal += cal;
    const card = document.createElement('div');
    card.className = 'food-card';
    card.innerHTML = `
      <div>
        <div class="food-card-name">${item.food}</div>
        <div class="food-card-sub">per 100g serving</div>
      </div>
      <div class="food-cal-badge">${cal} kcal</div>`;
    foodResults.appendChild(card);
  });
  if (totalCal > 0) {
    const total = document.createElement('div');
    total.style.cssText = 'text-align:center;padding:10px;color:var(--teal);font-weight:700;font-size:0.95rem;';
    total.textContent = `🔥 Total: ~${Math.round(totalCal)} kcal`;
    foodResults.appendChild(total);
  }
  if (evaluation) {
    const evalDiv = document.createElement('div');
    evalDiv.className = 'diet-result show';
    evalDiv.innerHTML = renderMarkdown(evaluation);
    foodResults.appendChild(evalDiv);
  }
}

// ── Diet Planner ──
document.getElementById('generateDietBtn').addEventListener('click', async () => {
  const report = document.getElementById('dietReport').value.trim();
  if (!report) { showToast('Please describe your health information first.'); return; }

  const btn = document.getElementById('generateDietBtn');
  const result = document.getElementById('dietResult');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner" style="width:18px;height:18px;border-width:2px;display:inline-block"></span> Generating...';
  result.classList.remove('show');

  try {
    const res = await fetch('/diet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ report })
    });
    const data = await res.json();
    result.innerHTML = renderMarkdown(data.plan || data.error || 'No plan generated.');
    result.classList.add('show');
  } catch (e) {
    result.innerHTML = '⚠️ Error generating plan. Check your connection.';
    result.classList.add('show');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '✨ Generate My Diet Plan';
  }
});

// ── Toast ──
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}
