import os
import requests


def generate_diet_plan(report):
    """
    Generate a personalized diet plan.
    Uses Gemini if API key is configured, otherwise Pollinations.ai (free).
    """
    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
    if gemini_key and gemini_key not in ("your_gemini_api_key_here", ""):
        try:
            return _diet_gemini(report, gemini_key)
        except Exception as e:
            print(f"[Gemini diet error, falling back]: {e}")

    return _diet_pollinations(report)


DIET_SYSTEM = (
    "You are a certified registered dietitian and nutritionist. "
    "Create personalized, practical, science-based meal plans. "
    "Use markdown with clear sections, tables, and bullet points."
)

DIET_TEMPLATE = """Based on the following health information, create a comprehensive personalized diet plan:

{report}

Please provide:
1. 📊 **Daily Nutritional Targets** (calories, protein, carbs, fats)
2. 🍽️ **7-Day Meal Plan** (breakfast, lunch, dinner, snacks)
3. ✅ **Recommended Foods**
4. ❌ **Foods to Avoid**
5. 💧 **Hydration Plan**
6. 💡 **Key Lifestyle Tips**"""


def _diet_gemini(report, api_key):
    import google.generativeai as genai
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(
        model_name="gemini-flash-latest",
        system_instruction=DIET_SYSTEM
    )
    response = model.generate_content(DIET_TEMPLATE.format(report=report))
    return response.text


def _diet_pollinations(report):
    try:
        messages = [
            {"role": "system", "content": DIET_SYSTEM},
            {"role": "user",   "content": DIET_TEMPLATE.format(report=report)}
        ]
        resp = requests.post(
            "https://text.pollinations.ai/",
            json={"messages": messages, "model": "openai", "private": True},
            timeout=60
        )
        if resp.status_code == 200:
            return resp.text.encode("utf-8", errors="replace").decode("utf-8")
        return f"⚠️ Could not generate plan (status {resp.status_code}). Please add your Gemini API key."
    except requests.Timeout:
        return "⚠️ Request timed out. Diet plans take a moment — please try again."
    except Exception as e:
        return f"⚠️ Error: {str(e)}"