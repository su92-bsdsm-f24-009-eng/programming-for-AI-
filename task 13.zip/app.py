from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import os
import base64
import uuid
from dotenv import load_dotenv

load_dotenv(override=True)

from models.food_detector import detect_food
from models.calorie_api import get_calories
from models.diet_planner import generate_diet_plan
from models.chatbot import ask_ai

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    try:
        data = request.json
        message = data.get("message", "").strip()
        image_data = data.get("image", None)  # base64 string
        history = data.get("history", [])

        if not message and not image_data:
            return jsonify({"error": "No message or image provided"}), 400

        if not message and image_data:
            message = "Please analyze this image and tell me what food you see, along with nutritional information."

        reply = ask_ai(message, image_data=image_data, history=history)
        return jsonify({"reply": reply})
    except Exception as e:
        return jsonify({"error": str(e), "reply": f"Sorry, something went wrong: {str(e)}"}), 500


@app.route("/upload", methods=["POST"])
def upload_image():
    try:
        image_data = None
        filename = None
        history = []

        if request.is_json:
            data = request.json
            history = data.get("history", [])
            image_b64 = data.get("image", "")
            if "," in image_b64:
                image_b64 = image_b64.split(",")[1]
            image_bytes = base64.b64decode(image_b64)
            filename = f"capture_{uuid.uuid4().hex[:8]}.jpg"
            path = os.path.join(UPLOAD_FOLDER, filename)
            with open(path, "wb") as f:
                f.write(image_bytes)
            image_data = data.get("image", "")
        else:
            if "image" not in request.files:
                return jsonify({"error": "No image provided"}), 400
            file = request.files["image"]
            filename = f"{uuid.uuid4().hex[:8]}_{file.filename}"
            path = os.path.join(UPLOAD_FOLDER, filename)
            file.save(path)
            with open(path, "rb") as f:
                image_data = "data:image/jpeg;base64," + base64.b64encode(f.read()).decode()

        # Detect food items
        foods = detect_food(path)

        results = []
        for food in foods:
            calories = get_calories(food)
            results.append({
                "food": food,
                "calories": calories
            })
            
        evaluation = ""
        # If we detected foods, evaluate them based on user history/goals
        if foods and all(f not in ["unknown food", "food item"] for f in foods):
            food_names = ", ".join(foods)
            prompt = f"I just scanned an image and it contains these foods: {food_names}. Based on my body goals and previous conversation, please evaluate if this is good for me and give me a complete nutritional breakdown."
            evaluation = ask_ai(prompt, image_data=image_data, history=history)

        image_url = f"/static/uploads/{filename}"
        return jsonify({"results": results, "evaluation": evaluation, "image_url": image_url})

    except Exception as e:
        return jsonify({"error": str(e), "results": []}), 500


@app.route("/diet", methods=["POST"])
def diet():
    try:
        data = request.json
        report = data.get("report", "").strip()
        if not report:
            return jsonify({"error": "No health report provided"}), 400
        plan = generate_diet_plan(report)
        return jsonify({"plan": plan})
    except Exception as e:
        return jsonify({"error": str(e), "plan": f"Error generating plan: {str(e)}"}), 500


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "message": "NutriAI is running!"})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)