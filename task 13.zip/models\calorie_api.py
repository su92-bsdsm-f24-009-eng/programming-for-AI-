import os

# Built-in calorie database fallback (per 100g approximate)
CALORIE_FALLBACK = {
    "apple": 52, "banana": 89, "orange": 47, "grape": 69, "strawberry": 32,
    "watermelon": 30, "mango": 60, "pineapple": 50, "blueberry": 57,
    "rice": 130, "white rice": 130, "brown rice": 123, "bread": 265,
    "pasta": 158, "noodle": 138, "noodles": 138, "oatmeal": 71,
    "chicken": 165, "chicken breast": 165, "beef": 250, "pork": 242,
    "fish": 136, "salmon": 208, "tuna": 132, "shrimp": 99, "egg": 155,
    "milk": 61, "cheese": 402, "yogurt": 59, "butter": 717,
    "broccoli": 55, "carrot": 41, "spinach": 23, "tomato": 18,
    "potato": 77, "sweet potato": 86, "corn": 96, "peas": 81,
    "onion": 40, "garlic": 149, "cucumber": 15, "lettuce": 15,
    "pizza": 266, "burger": 295, "sandwich": 250, "salad": 20,
    "soup": 50, "stew": 120, "curry": 150, "fried rice": 163,
    "chocolate": 546, "cake": 350, "cookie": 502, "ice cream": 207,
    "coffee": 2, "tea": 1, "juice": 45, "soda": 41,
    "almond": 579, "walnut": 654, "peanut": 567, "cashew": 553,
    "avocado": 160, "beans": 127, "lentil": 116, "tofu": 76,
    "donut": 452, "bagel": 245, "croissant": 406, "waffle": 291,
    "pancake": 227, "cereal": 379, "granola": 471,
}

def get_calories(food_name):
    """Get calories for a food item. Tries Gemini API first, then built-in fallback."""
    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
    if gemini_key and gemini_key not in ("your_gemini_api_key_here", ""):
        try:
            return _get_from_gemini(food_name, gemini_key)
        except Exception as e:
            print(f"[Gemini calorie error, falling back]: {e}")

    # Fallback: built-in database
    return _get_from_fallback(food_name)

def _get_from_gemini(food_name, api_key):
    try:
        import google.generativeai as genai
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel("gemini-flash-latest")
        
        prompt = f"How many calories are in 100g of {food_name}? Respond with ONLY the number and nothing else (e.g. '52' or '130')."
        response = model.generate_content(prompt)
        text = response.text.strip().replace("kcal", "").replace("calories", "").strip()
        
        # Try to extract just the number
        import re
        match = re.search(r'\d+', text)
        if match:
            return int(match.group())
    except Exception as e:
        print(f"Gemini error: {e}")
    
    return _get_from_fallback(food_name)

def _get_from_fallback(food_name):
    """Look up calories from built-in database."""
    name_lower = food_name.lower().strip()

    # Direct match
    if name_lower in CALORIE_FALLBACK:
        return CALORIE_FALLBACK[name_lower]

    # Partial match
    for key, cal in CALORIE_FALLBACK.items():
        if key in name_lower or name_lower in key:
            return cal

    # Default estimate
    return "~200 (est.)"