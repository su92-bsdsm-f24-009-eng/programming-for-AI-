import re


def parse_health_report(text):
    """Extract key health metrics from a free-text health report."""
    result = {
        "age": None,
        "weight": None,
        "height": None,
        "gender": None,
        "conditions": [],
        "goal": None,
        "activity_level": None,
    }

    # Age
    age_match = re.search(r"\b(\d{1,3})\s*(?:years?\s*old|yr|age)", text, re.IGNORECASE)
    if age_match:
        result["age"] = int(age_match.group(1))

    # Weight (kg or lbs)
    weight_match = re.search(r"\b(\d{2,3}(?:\.\d+)?)\s*(?:kg|kilograms?|lbs?|pounds?)", text, re.IGNORECASE)
    if weight_match:
        result["weight"] = weight_match.group(0)

    # Height
    height_match = re.search(r"\b(\d{1,3}(?:\.\d+)?)\s*(?:cm|feet|ft|m\b)", text, re.IGNORECASE)
    if height_match:
        result["height"] = height_match.group(0)

    # Gender
    if re.search(r"\b(male|man|boy)\b", text, re.IGNORECASE):
        result["gender"] = "male"
    elif re.search(r"\b(female|woman|girl)\b", text, re.IGNORECASE):
        result["gender"] = "female"

    # Common conditions
    conditions_map = {
        "diabetes": ["diabet", "blood sugar"],
        "hypertension": ["hypertension", "high blood pressure", "bp"],
        "obesity": ["obes", "overweight"],
        "heart disease": ["heart disease", "cardiac", "cardiovascular"],
        "celiac": ["celiac", "gluten"],
        "lactose intolerance": ["lactose"],
        "kidney disease": ["kidney", "renal"],
    }
    for condition, keywords in conditions_map.items():
        for kw in keywords:
            if kw.lower() in text.lower():
                result["conditions"].append(condition)
                break

    # Goal
    if re.search(r"\b(lose|loss|weight loss|slim|cut)\b", text, re.IGNORECASE):
        result["goal"] = "weight loss"
    elif re.search(r"\b(gain|bulk|muscle|build)\b", text, re.IGNORECASE):
        result["goal"] = "muscle gain"
    elif re.search(r"\b(maintain|healthy|balance)\b", text, re.IGNORECASE):
        result["goal"] = "maintain weight"

    return result


def format_food_results(results):
    """Format food detection results as a readable string."""
    if not results:
        return "No food items detected."
    lines = []
    total = 0
    for item in results:
        cal = item.get("calories", "N/A")
        lines.append(f"• **{item['food'].title()}** — {cal} kcal")
        if isinstance(cal, (int, float)):
            total += cal
    if total > 0:
        lines.append(f"\n**Total estimated calories: {round(total)} kcal**")
    return "\n".join(lines)
