import base64
import io
import os
from PIL import Image


def decode_base64_image(b64_string):
    """Decode a base64 image string to bytes."""
    if "," in b64_string:
        b64_string = b64_string.split(",")[1]
    return base64.b64decode(b64_string)


def encode_image_to_base64(image_path):
    """Encode an image file to base64 string."""
    with open(image_path, "rb") as f:
        return base64.b64encode(f.read()).decode("utf-8")


def resize_image(image_bytes, max_size=(1024, 1024), quality=85):
    """Resize and compress image bytes for efficient upload."""
    try:
        img = Image.open(io.BytesIO(image_bytes))
        if img.mode not in ("RGB", "RGBA"):
            img = img.convert("RGB")
        img.thumbnail(max_size, Image.LANCZOS)
        output = io.BytesIO()
        img.save(output, format="JPEG", quality=quality, optimize=True)
        return output.getvalue()
    except Exception as e:
        print(f"Image resize error: {e}")
        return image_bytes


def save_image_from_base64(b64_string, save_dir, filename=None):
    """Decode and save a base64 image to disk."""
    import uuid
    image_bytes = decode_base64_image(b64_string)
    image_bytes = resize_image(image_bytes)
    if not filename:
        filename = f"{uuid.uuid4().hex[:8]}.jpg"
    path = os.path.join(save_dir, filename)
    with open(path, "wb") as f:
        f.write(image_bytes)
    return path, image_bytes


def get_image_data_url(image_path):
    """Get a base64 data URL from an image file path."""
    b64 = encode_image_to_base64(image_path)
    ext = os.path.splitext(image_path)[1].lower()
    mime = "image/jpeg" if ext in (".jpg", ".jpeg") else f"image/{ext[1:]}"
    return f"data:{mime};base64,{b64}"
