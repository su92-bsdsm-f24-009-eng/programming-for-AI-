from flask import Flask, render_template, request, jsonify
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer

# Download lexicon on startup
nltk.download('vader_lexicon', quiet=True)
sid = SentimentIntensityAnalyzer()

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()
    text = data.get('text', '')
    
    if not text.strip():
        return jsonify({'error': 'Please enter some text.'}), 400

    scores = sid.polarity_scores(text)
    
    # Determine overall sentiment label
    if scores['compound'] >= 0.05:
        overall = 'Positive'
    elif scores['compound'] <= -0.05:
        overall = 'Negative'
    else:
        overall = 'Neutral'
        
    return jsonify({
        'scores': scores,
        'overall': overall,
        'text': text
    })

if __name__ == '__main__':
    app.run(debug=True, port=5000)
