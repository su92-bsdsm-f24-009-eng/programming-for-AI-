document.addEventListener('DOMContentLoaded', () => {
    const analyzeBtn = document.getElementById('analyze-btn');
    const textInput = document.getElementById('text-input');
    const resultSection = document.getElementById('result-section');
    
    const overallSentiment = document.getElementById('overall-sentiment');
    const scorePos = document.getElementById('score-pos');
    const scoreNeu = document.getElementById('score-neu');
    const scoreNeg = document.getElementById('score-neg');
    const scoreCompound = document.getElementById('score-compound');

    analyzeBtn.addEventListener('click', async () => {
        const text = textInput.value.trim();
        
        if (!text) {
            alert('Please enter some text to analyze.');
            return;
        }

        analyzeBtn.textContent = 'Analyzing...';
        analyzeBtn.disabled = true;

        try {
            const response = await fetch('/analyze', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ text })
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const data = await response.json();
            updateUI(data);

        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while analyzing the sentiment.');
        } finally {
            analyzeBtn.textContent = 'Analyze Sentiment';
            analyzeBtn.disabled = false;
        }
    });

    function updateUI(data) {
        // Remove hidden class if present
        resultSection.classList.remove('hidden');
        
        // Update label and color
        overallSentiment.textContent = data.overall;
        overallSentiment.className = `sentiment-label ${data.overall.toLowerCase()}`;
        
        // Update scores
        animateValue(scorePos, parseFloat(scorePos.textContent), data.scores.pos, 1000);
        animateValue(scoreNeu, parseFloat(scoreNeu.textContent), data.scores.neu, 1000);
        animateValue(scoreNeg, parseFloat(scoreNeg.textContent), data.scores.neg, 1000);
        animateValue(scoreCompound, parseFloat(scoreCompound.textContent), data.scores.compound, 1000, true);
    }

    function animateValue(obj, start, end, duration, isCompound = false) {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            
            let current = progress * (end - start) + start;
            
            // Format differently if compound (can be negative)
            let formatted = current.toFixed(3);
            if (isCompound && current > 0) formatted = '+' + formatted;
            
            obj.innerHTML = formatted;
            
            if (progress < 1) {
                window.requestAnimationFrame(step);
            } else {
                let final = end.toFixed(3);
                if (isCompound && end > 0) final = '+' + final;
                obj.innerHTML = final;
            }
        };
        window.requestAnimationFrame(step);
    }
});
