"""
HadithBot — Standalone Flask server
Run this file directly if you don't want to use the Jupyter notebook:

    python app.py

Make sure you have already built the index (run the notebook first, or run
`python build_index.py` to generate the data files).
"""

import os
import sys

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS

# ── Paths ─────────────────────────────────────────────────────────────────────
ROOT        = os.path.dirname(__file__)
DATA_DIR    = os.path.join(ROOT, 'data')
CSV_PATH    = os.path.join(DATA_DIR, 'cleaned_hadith_data.csv')
EMBED_PATH  = os.path.join(DATA_DIR, 'hadith_embeddings.npy')
INDEX_PATH  = os.path.join(DATA_DIR, 'faiss_index.index')

# ── Lazy-load heavy dependencies ──────────────────────────────────────────────
print("Loading dependencies…")
import re
import numpy as np
import pandas as pd
import faiss
from sentence_transformers import SentenceTransformer

# ── Load artefacts ────────────────────────────────────────────────────────────
for path, label in [(CSV_PATH, 'cleaned_hadith_data.csv'),
                    (EMBED_PATH, 'hadith_embeddings.npy'),
                    (INDEX_PATH, 'faiss_index.index')]:
    if not os.path.exists(path):
        sys.exit(
            f"\n❌  Missing file: {path}\n"
            "    Run the Jupyter notebook first (or `python build_index.py`) "
            "to generate the required data files.\n"
        )

print("Loading hadith data…")
hadith_df   = pd.read_csv(CSV_PATH)

print("Loading embeddings…")
embeddings  = np.load(EMBED_PATH).astype('float32')

print("Loading FAISS index…")
faiss_index = faiss.read_index(INDEX_PATH)

print("Loading sentence encoder…")
encoder     = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

print(f"✅  Ready — {faiss_index.ntotal:,} hadith indexed.")


# ── Helpers ───────────────────────────────────────────────────────────────────
def clean_text(text: str) -> str:
    text = str(text).lower()
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def get_similar_hadith(query: str, top_k: int = 5) -> list[dict]:
    query_vec = encoder.encode([clean_text(query)], convert_to_numpy=True).astype('float32')
    distances, indices = faiss_index.search(query_vec, top_k)

    results = []
    for rank, (dist, idx) in enumerate(zip(distances[0], indices[0]), start=1):
        row = hadith_df.iloc[idx]
        similarity = max(0.0, round(100 / (1 + dist), 1))
        results.append({
            'rank':           rank,
            'similarity':     similarity,
            'hadith_number':  str(row.get('Hadith_Number', '')),
            'chapter':        str(row.get('Chapter_English', '')),
            'section':        str(row.get('Section_English', '')),
            'english_hadith': str(row.get('English_Hadith', '')),
            'arabic_hadith':  str(row.get('Arabic_Hadith', '')),
            'grade':          str(row.get('English_Grade', '')),
            'isnad':          str(row.get('English_Isnad', '')),
        })
    return results


# ── Flask app ─────────────────────────────────────────────────────────────────
app = Flask(__name__, template_folder='templates', static_folder='static')
CORS(app)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/search', methods=['POST'])
def search():
    data  = request.get_json(force=True)
    query = (data.get('query') or '').strip()
    top_k = min(int(data.get('top_k', 5)), 20)

    if not query:
        return jsonify({'error': 'Query is empty.'}), 400

    try:
        results = get_similar_hadith(query, top_k=top_k)
        return jsonify({'query': query, 'results': results})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/health')
def health():
    return jsonify({'status': 'ok', 'total_hadith': int(faiss_index.ntotal)})


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
