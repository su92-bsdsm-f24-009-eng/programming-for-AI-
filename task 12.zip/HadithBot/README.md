# 📖 HadithBot — Semantic Hadith Search Engine

A semantic search engine over the **LK Hadith Corpus** using:
- **SentenceTransformers** (`all-MiniLM-L6-v2`) for dense text embeddings
- **FAISS** (Facebook AI Similarity Search) for fast nearest-neighbour retrieval
- **Flask** + a custom frontend for the web interface

---

## 🗂 Project Structure

```
HadithBot/
├── notebooks/
│   └── HadithBot.ipynb      ← Full pipeline + embedded Flask server
├── templates/
│   └── index.html           ← Frontend UI
├── static/
│   ├── css/style.css
│   └── js/app.js
├── data/                    ← Created automatically at runtime
│   ├── LK-Hadith-Corpus/    ← Git-cloned dataset
│   ├── cleaned_hadith_data.csv
│   ├── hadith_embeddings.npy
│   └── faiss_index.index
├── app.py                   ← Standalone Flask server (run after building index)
├── build_index.py           ← One-shot script to build all data files
└── requirements.txt
```

---

## 🚀 Option A — Jupyter Notebook (Recommended)

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Open the notebook
```bash
jupyter notebook notebooks/HadithBot.ipynb
```

### 3. Run all cells top-to-bottom

The notebook will:
1. Install any missing packages
2. Clone the LK Hadith Corpus (~40 MB)
3. Load and clean all CSV files
4. Encode hadith into 384-dim embeddings (one-time, ~5–15 min depending on hardware)
5. Build and save the FAISS index
6. Start the Flask web server on **http://localhost:5000**

> ⚠️ The last cell (Step 9) runs the Flask server and blocks until you stop it.  
> To stop: press **■** in the Jupyter toolbar or go to **Kernel → Interrupt**.

---

## 🚀 Option B — Standalone Script

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Build the corpus & index (run once)
python build_index.py

# 3. Start the web server
python app.py
```

Open **http://localhost:5000** in your browser.

---

## 🔍 How It Works

1. **Corpus ingestion** — All hadith CSVs are loaded, cleaned (lowercased, punctuation stripped), and merged into a single DataFrame.
2. **Embedding** — Each hadith is encoded using `all-MiniLM-L6-v2`, producing a 384-dimensional float vector that captures semantic meaning.
3. **FAISS index** — Vectors are added to a `IndexFlatL2` index (exact Euclidean distance search). The index and embeddings are cached to disk so this expensive step only runs once.
4. **Search** — At query time, the user's question is encoded into the same embedding space, and FAISS returns the top-K nearest hadith vectors. L2 distance is converted to a 0–100 similarity score.
5. **Frontend** — A single-page Flask app renders results as interactive cards. Clicking a card opens a detail modal with the full Arabic and English text, chain of narration (isnad), and grade.

---

## 📦 Data Source

[LK Hadith Corpus](https://github.com/ShathaTm/LK-Hadith-Corpus) by ShathaTm — a curated, structured collection of authenticated hadith with English translations, Arabic text, isnad, matn, and grades.

---

## 💻 Requirements

- Python 3.10+
- ~2 GB RAM for embedding + FAISS
- Internet connection (first run only, for corpus clone and model download)
