"""
build_index.py — Run this once to download the corpus and build the FAISS index.

Usage:
    python build_index.py

Outputs (saved to ./data/):
    cleaned_hadith_data.csv
    hadith_embeddings.npy
    faiss_index.index
"""

import os
import re
import glob
import subprocess

import numpy as np
import pandas as pd
import faiss
from sentence_transformers import SentenceTransformer

# ── Config ────────────────────────────────────────────────────────────────────
ROOT        = os.path.dirname(__file__)
DATA_DIR    = os.path.join(ROOT, 'data')
CORPUS_PATH = os.path.join(DATA_DIR, 'LK-Hadith-Corpus')
CSV_PATH    = os.path.join(DATA_DIR, 'cleaned_hadith_data.csv')
EMBED_PATH  = os.path.join(DATA_DIR, 'hadith_embeddings.npy')
INDEX_PATH  = os.path.join(DATA_DIR, 'faiss_index.index')

os.makedirs(DATA_DIR, exist_ok=True)

# ── Step 1: Clone corpus ──────────────────────────────────────────────────────
if not os.path.exists(CORPUS_PATH):
    print("Cloning LK Hadith Corpus…")
    subprocess.run(
        ['git', 'clone', 'https://github.com/ShathaTm/LK-Hadith-Corpus.git', CORPUS_PATH],
        check=True
    )
    print("✅  Corpus cloned.")
else:
    print("✅  Corpus already present.")

# ── Step 2: Load & clean CSVs ─────────────────────────────────────────────────
COLUMNS = [
    'Chapter_Number', 'Chapter_English', 'Chapter_Arabic',
    'Section_Number', 'Section_English', 'Section_Arabic',
    'Hadith_Number',
    'English_Hadith', 'English_Isnad', 'English_Matn', 'English_Grade',
    'Arabic_Hadith', 'Arabic_Isnad', 'Arabic_Matn', 'Arabic_Grade',
    'Cleaned_Hadith'
]
raw_cols = COLUMNS[:-1]

def clean_text(text):
    text = str(text).lower()
    text = re.sub(r'[^a-zA-Z0-9\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

files = sorted(glob.glob(CORPUS_PATH + '/**/*.csv', recursive=True))
print(f"Found {len(files)} CSV file(s).")

rows = []
for f in files:
    try:
        df = pd.read_csv(f, names=raw_cols, skiprows=1)
        df['Cleaned_Hadith'] = df['English_Hadith'].astype(str).apply(clean_text)
        rows.append(df[COLUMNS])
    except Exception as e:
        print(f"  ⚠️  Skipping {f}: {e}")

hadith_df = pd.concat(rows, ignore_index=True)
hadith_df = hadith_df[hadith_df['Cleaned_Hadith'].str.strip() != ''].reset_index(drop=True)
print(f"✅  Loaded {len(hadith_df):,} hadith records.")

hadith_df.to_csv(CSV_PATH, index=False)
print(f"✅  Saved cleaned data → {CSV_PATH}")

# ── Step 3: Embeddings ────────────────────────────────────────────────────────
if os.path.exists(EMBED_PATH):
    print("✅  Embeddings already exist — loading.")
    embeddings = np.load(EMBED_PATH)
else:
    print("Encoding hadith with all-MiniLM-L6-v2 (this may take a few minutes)…")
    encoder = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
    embeddings = encoder.encode(
        hadith_df['Cleaned_Hadith'].tolist(),
        batch_size=256,
        show_progress_bar=True,
        convert_to_numpy=True
    )
    np.save(EMBED_PATH, embeddings)
    print(f"✅  Embeddings saved → {EMBED_PATH}")

# ── Step 4: FAISS index ───────────────────────────────────────────────────────
if os.path.exists(INDEX_PATH):
    print("✅  FAISS index already exists.")
else:
    print("Building FAISS index…")
    dim = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings.astype('float32'))
    faiss.write_index(index, INDEX_PATH)
    print(f"✅  FAISS index saved → {INDEX_PATH}")

print("\n🎉  All done! Run `python app.py` to start the web server.")
