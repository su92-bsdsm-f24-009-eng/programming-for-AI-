'use strict';

// ── DOM refs ──────────────────────────────────────────────────────────────────
const queryInput    = document.getElementById('queryInput');
const topKSelect    = document.getElementById('topK');
const searchBtn     = document.getElementById('searchBtn');
const cardsGrid     = document.getElementById('cardsGrid');
const loader        = document.getElementById('loader');
const errorWrap     = document.getElementById('errorWrap');
const errorMsg      = document.getElementById('errorMsg');
const placeholder   = document.getElementById('placeholder');
const resultsHeader = document.getElementById('resultsHeader');
const resultsMeta   = document.getElementById('resultsMeta');
const chipRow       = document.getElementById('chipRow');
const metaDot       = document.querySelector('.meta-dot');
const metaText      = document.getElementById('metaText');
const modalOverlay  = document.getElementById('modalOverlay');
const modalContent  = document.getElementById('modalContent');
const modalClose    = document.getElementById('modalClose');

// ── Health check ──────────────────────────────────────────────────────────────
async function checkHealth() {
  try {
    const res = await fetch('/health');
    if (res.ok) {
      const data = await res.json();
      metaDot.classList.add('online');
      metaText.textContent = `${Number(data.total_hadith).toLocaleString()} hadith indexed`;
    } else {
      metaText.textContent = 'Server error';
    }
  } catch {
    metaText.textContent = 'Offline';
  }
}
checkHealth();

// ── Score colour ──────────────────────────────────────────────────────────────
function scoreClass(score) {
  if (score >= 30) return 'score-high';
  if (score >= 15) return 'score-medium';
  return 'score-low';
}

// ── Truncate ──────────────────────────────────────────────────────────────────
function trunc(str, n = 340) {
  if (!str || str === 'nan') return '';
  return str.length > n ? str.slice(0, n).trimEnd() + '…' : str;
}

function clean(str) {
  if (!str || str === 'nan') return '';
  return str.trim();
}

// ── Build card ────────────────────────────────────────────────────────────────
function buildCard(item, delay) {
  const card = document.createElement('article');
  card.className = 'hadith-card';
  card.style.animationDelay = `${delay * 60}ms`;
  card.dataset.rank = item.rank;

  const chapter = clean(item.chapter) || 'Unknown Chapter';
  const grade   = clean(item.grade)   || '—';
  const text    = clean(item.english_hadith);

  card.innerHTML = `
    <div class="card-header">
      <span class="card-rank">#${item.rank}</span>
      <span class="card-chapter">${escHtml(chapter)}</span>
      <span class="card-score ${scoreClass(item.similarity)}">${item.similarity}%</span>
    </div>
    <div class="card-body">
      <p class="card-hadith-text">${escHtml(trunc(text))}</p>
    </div>
    <div class="card-footer">
      <span class="card-grade">${escHtml(grade)}</span>
      <span class="card-read-more">Read full hadith →</span>
    </div>
  `;

  card.addEventListener('click', () => openModal(item));
  return card;
}

// ── Open modal ────────────────────────────────────────────────────────────────
function openModal(item) {
  const chapter = clean(item.chapter) || 'Unknown Chapter';
  const section = clean(item.section) || '';
  const english = clean(item.english_hadith);
  const arabic  = clean(item.arabic_hadith);
  const grade   = clean(item.grade);
  const isnad   = clean(item.isnad);
  const num     = clean(item.hadith_number);

  let html = `
    <p class="modal-rank">Result #${item.rank} · Similarity ${item.similarity}%</p>
    <h2 class="modal-chapter">${escHtml(chapter)}</h2>
    ${section ? `<p class="modal-section">${escHtml(section)}</p>` : ''}
    <hr class="modal-divider" />
    <p class="modal-label">English Translation</p>
    <p class="modal-english">${escHtml(english)}</p>
  `;

  if (arabic && arabic !== 'nan') {
    html += `
      <p class="modal-label">Arabic Text</p>
      <div class="modal-arabic">${escHtml(arabic)}</div>
    `;
  }

  html += `<div class="modal-meta">`;
  if (num)   html += `<span class="meta-tag"><span>Hadith</span>${escHtml(num)}</span>`;
  if (grade) html += `<span class="meta-tag"><span>Grade</span>${escHtml(grade)}</span>`;
  if (isnad) html += `<span class="meta-tag"><span>Isnad</span>${escHtml(trunc(isnad, 80))}</span>`;
  html += `</div>`;

  modalContent.innerHTML = html;
  modalOverlay.classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  modalOverlay.classList.add('hidden');
  document.body.style.overflow = '';
}

modalClose.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

// ── HTML escape ────────────────────────────────────────────────────────────────
function escHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ── UI state helpers ───────────────────────────────────────────────────────────
function setLoading(on) {
  loader.classList.toggle('hidden', !on);
  placeholder.classList.add('hidden');
  searchBtn.classList.toggle('loading', on);
  searchBtn.disabled = on;
  if (on) {
    cardsGrid.innerHTML = '';
    resultsHeader.classList.add('hidden');
    errorWrap.classList.add('hidden');
  }
}

function showError(msg) {
  errorMsg.textContent = msg;
  errorWrap.classList.remove('hidden');
  resultsHeader.classList.add('hidden');
}

// ── Search ────────────────────────────────────────────────────────────────────
async function doSearch(rawQuery) {
  const query = (rawQuery || queryInput.value).trim();
  if (!query) { queryInput.focus(); return; }

  const topK = parseInt(topKSelect.value, 10);
  setLoading(true);

  try {
    const res = await fetch('/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, top_k: topK })
    });

    const data = await res.json();

    if (!res.ok || data.error) {
      showError(data.error || 'An unexpected error occurred.');
      return;
    }

    const results = data.results || [];
    cardsGrid.innerHTML = '';

    if (results.length === 0) {
      showError('No results found. Try a different query.');
      return;
    }

    resultsMeta.textContent =
      `${results.length} result${results.length !== 1 ? 's' : ''} for "${query}"`;
    resultsHeader.classList.remove('hidden');

    results.forEach((item, i) => cardsGrid.appendChild(buildCard(item, i)));

  } catch (err) {
    showError('Could not reach the server. Is the Flask app running?');
    console.error(err);
  } finally {
    setLoading(false);
  }
}

// ── Event listeners ────────────────────────────────────────────────────────────
searchBtn.addEventListener('click', () => doSearch());

queryInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSearch(); }
});

chipRow.querySelectorAll('.chip').forEach(chip => {
  chip.addEventListener('click', () => {
    const q = chip.dataset.q;
    queryInput.value = q;
    doSearch(q);
  });
});
