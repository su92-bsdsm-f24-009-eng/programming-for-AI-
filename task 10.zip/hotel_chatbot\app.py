from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)

def get_bot_response(user_message):
    message = user_message.lower()
    
    # Keyword patterns
    if re.search(r'\b(room|types|rooms)\b', message):
        return "We offer three types of rooms: Standard ($100/night), Deluxe ($150/night), and Executive Suite ($250/night)."
    elif re.search(r'\b(price|prices|cost|rate|rates)\b', message):
        return "Our rates start at $100 for Standard, $150 for Deluxe, and $250 for Suites per night."
    elif re.search(r'\b(amenities|amenity|facilities|pool|gym|wifi|spa)\b', message):
        return "Our hotel features a heated indoor pool, a 24/7 fitness center, complimentary high-speed Wi-Fi, and a full-service spa."
    elif re.search(r'\b(book|booking|reservation|reserve)\b', message):
        return "You can book a room directly on our website or by calling our reception at 1-800-HOTEL-BOOK. Check-in is at 3:00 PM and check-out is at 11:00 AM."
    elif re.search(r'\b(hi|hello|hey|greetings)\b', message):
        return "Hello! Welcome to our Hotel. How can I assist you today? You can ask me about room types, prices, amenities, or booking info."
    else:
        return "I'm sorry, I didn't quite catch that. You can ask me about our room types, prices, amenities, or booking information."

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_message = request.json.get('message', '')
    bot_response = get_bot_response(user_message)
    return jsonify({"response": bot_response})

if __name__ == '__main__':
    app.run(debug=True, port=5000)
